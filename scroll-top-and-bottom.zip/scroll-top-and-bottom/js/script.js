			jQuery(document).ready(function() {

				jQuery(window).scroll(function() {
				      if (jQuery(this).scrollTop() > 200) {
				          jQuery('#scroll-to-bottom').fadeOut('slow');
				      } 
				 });   
			
            });